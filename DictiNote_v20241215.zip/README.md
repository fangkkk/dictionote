# DictiNote - 简单的便签软件

一个简单、易用的便签软件，支持按日期管理便签。

## 功能特点

- 按日期管理便签
- 支持未来日期规划
- 自定义字体和颜色
- 自动保存
- 简洁的界面

## 安装方法

### 方法一：直接下载可执行文件

1. 从 [Releases](https://github.com/yourusername/dictionote/releases) 页面下载最新版本
2. 解压后直接运行 `DictiNote.exe`

### 方法二：从源码安装

1. 克隆仓库： 